"""
MeshCore GUI — Dual Transport Edition (Serial + BLE).

A graphical user interface for MeshCore mesh network devices,
communicating via USB serial or Bluetooth Low Energy (BLE).
"""

__version__ = "5.0"
