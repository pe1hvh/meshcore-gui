"""
Connection layer — device connection, commands and events.
"""
