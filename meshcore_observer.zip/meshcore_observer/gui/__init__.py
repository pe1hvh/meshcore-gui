"""Observer GUI package."""
