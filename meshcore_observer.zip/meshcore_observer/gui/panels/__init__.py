"""Observer dashboard panels."""
